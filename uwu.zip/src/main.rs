use std::{process::Command, ptr};

use x11::xlib::{XStoreName, _XDisplay, XOpenDisplay};

fn main() {
    let display = unsafe { XOpenDisplay(ptr::null()) };
    let mut bar = Bar::new(Seperator(" | ".to_string()));
    loop {
        let status = "balls".to_string();
        unsafe { XStoreName(display, 0, status.as_ptr() as *const i8); }
    }
    
}


struct Bar {
    seperator: Seperator,
    modules: Vec<Module>,
}

struct Seperator(String);


#[derive(Clone)]
struct Module {
    cached_string: String,
    command: Execute,
    interval: u64, // in miliseconds
}
#[derive(Clone)]
struct Execute {
    command: String,
    args: Vec<String>,
}

impl Execute {
    fn run(&self) -> String {
        let stdout = Command::new(self.command.clone())
            .args(self.args.clone())
            .output()
            .unwrap()
            .stdout;
        String::from_utf8(stdout).unwrap()
    }
    fn new(command: String) -> Execute {
        let command = shellwords::split(&command).unwrap();
        Execute {
            command: command[0].clone(),
            args: command[1..].into(),
        }
    }
}

impl Module {
    fn new(command: String, interval: u64) -> Module {
        let mut module = Module {
            cached_string: String::new(),
            command: Execute::new(command),
            interval,
        };
        module.run();
        module
    }
    fn run(&mut self) -> String {
        self.command.run()
    }
}



impl Bar {
    fn new(seperator: Seperator) -> Bar {
        Bar {
            seperator,
            modules: Vec::new(),
        }
    }
    fn get_status(&mut self) -> String {
        let mut s = String::new();
        for mut module in self.modules.clone() {
            s += &module.run();
            s += &self.seperator.0;
        }
        s
    }
}



